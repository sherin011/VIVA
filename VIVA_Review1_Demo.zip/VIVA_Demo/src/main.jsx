import React, {useEffect, useRef, useState} from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

function App(){
  const videoRef=useRef(null), streamRef=useRef(null), recorderRef=useRef(null), chunksRef=useRef([]);
  const [screen,setScreen]=useState("home");
  const [name,setName]=useState("");
  const [email,setEmail]=useState("");
  const [recording,setRecording]=useState(false);
  const [seconds,setSeconds]=useState(0);
  const [mediaReady,setMediaReady]=useState(false);
  const [error,setError]=useState("");

  useEffect(()=>()=>{streamRef.current?.getTracks().forEach(t=>t.stop())},[]);
  useEffect(()=>{ if(!recording)return; const id=setInterval(()=>setSeconds(s=>s+1),1000); return()=>clearInterval(id)},[recording]);

  const startInterview=()=>{ if(!name.trim()){setError("Please enter candidate name.");return} setError("");setScreen("interview"); };
  const enableCamera=async()=>{
    try{
      const stream=await navigator.mediaDevices.getUserMedia({video:true,audio:true});
      streamRef.current=stream; setMediaReady(true);
      setTimeout(()=>{if(videoRef.current){videoRef.current.srcObject=stream;videoRef.current.play()}},50);
    }catch(e){setError("Camera/Microphone permission is required for the demo.");}
  };
  const startRecording=()=>{
    if(!streamRef.current){setError("Enable camera and microphone first.");return}
    chunksRef.current=[];
    const rec=new MediaRecorder(streamRef.current);
    recorderRef.current=rec;
    rec.ondataavailable=e=>{if(e.data.size)chunksRef.current.push(e.data)};
    rec.onstop=()=>{streamRef.current?.getTracks().forEach(t=>t.stop());setRecording(false);setScreen("processing");
      setTimeout(()=>setScreen("result"),2500)};
    rec.start();setSeconds(0);setRecording(true);
  };
  const stopRecording=()=>recorderRef.current?.stop();
  const reset=()=>{setScreen("home");setName("");setEmail("");setSeconds(0);setMediaReady(false);setError("")};

  return <div className="app">
    <header><div className="brand">VIVA</div><div className="tag">Voice & Video Integrity Verification</div></header>
    {screen==="home"&&<main className="center"><section className="hero">
      <span className="pill">AI-BASED INTERVIEW AUTHENTICATION</span>
      <h1>Verify the authenticity<br/>of online interviews.</h1>
      <p>Prototype workflow for capturing candidate video and audio for deepfake analysis.</p>
      <div className="form"><input placeholder="Candidate name" value={name} onChange={e=>setName(e.target.value)}/><input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)}/><button onClick={startInterview}>Start Interview →</button></div>
      {error&&<p className="error">{error}</p>}
    </section></main>}
    {screen==="interview"&&<main className="center"><section className="card wide">
      <div className="toprow"><div><span className="pill">INTERVIEW SESSION</span><h2>Candidate Verification</h2></div><div className="status">● {mediaReady?"Ready":"Camera Off"}</div></div>
      <div className="videoBox">{mediaReady?<video ref={videoRef} muted playsInline/>:<div className="cameraPlaceholder"><div className="camIcon">◉</div><p>Camera preview</p><small>Enable camera & microphone to begin</small></div>}</div>
      <div className="controls"><div>🎤 Microphone <b>{mediaReady?"ON":"OFF"}</b></div><div>Recording <b>{String(Math.floor(seconds/60)).padStart(2,"0")}:{String(seconds%60).padStart(2,"0")}</b></div></div>
      {!mediaReady?<button onClick={enableCamera}>Enable Camera & Mic</button>:!recording?<button onClick={startRecording}>Start Recording</button>:<button className="danger" onClick={stopRecording}>Stop & Submit</button>}
      {error&&<p className="error">{error}</p>}
    </section></main>}
    {screen==="processing"&&<main className="center"><section className="card processing"><span className="loader"></span><h2>Analyzing Interview...</h2><div className="steps"><p>✓ Video captured</p><p>✓ Audio captured</p><p>✓ Preparing video frames</p><p>⏳ Video authenticity analysis</p><p>⏳ Voice authenticity analysis</p></div><small>Prototype processing screen. AI model integration is the next phase.</small></section></main>}
    {screen==="result"&&<main className="center"><section className="card">
      <span className="pill">PRELIMINARY PROTOTYPE OUTPUT</span><h2>VIVA Authentication Result</h2>
      <div className="scores"><div><span>Video Analysis</span><strong>82%</strong><small>TimeSformer</small></div><div><span>Voice Analysis</span><strong>76%</strong><small>Wav2Vec 2.0</small></div></div>
      <div className="final"><small>Overall authenticity score</small><strong>79%</strong><b>LIKELY GENUINE</b></div>
      <p className="note">These values are illustrative prototype output for Review 1 and are not model accuracy measurements.</p>
      <button onClick={reset}>Run Another Demo</button>
    </section></main>}
  </div>
}
createRoot(document.getElementById("root")).render(<App/>);
