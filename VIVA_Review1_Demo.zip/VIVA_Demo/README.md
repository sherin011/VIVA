# VIVA Review 1 Demo

## Run
1. Install Node.js.
2. Open this folder in VS Code.
3. Run `npm install`
4. Run `npm run dev`
5. Open the localhost URL shown by Vite.
6. Allow camera and microphone access.

## Review 1 scope
This prototype demonstrates the candidate interview capture workflow and a preliminary result UI. The displayed AI scores are illustrative prototype values only. TimeSformer and Wav2Vec 2.0 integration is the next development phase.

## Planned architecture
React frontend → FastAPI backend → OpenCV preprocessing → TimeSformer video analysis + Wav2Vec 2.0 voice analysis → fusion → PostgreSQL results.
